# Graph Panel

This is the main Graph panel and is **included** with Grafana. It provides a very rich set of graphing options.

For full reference documentation:

[http://docs.grafana.org/reference/graph/](http://docs.grafana.org/reference/graph/)
